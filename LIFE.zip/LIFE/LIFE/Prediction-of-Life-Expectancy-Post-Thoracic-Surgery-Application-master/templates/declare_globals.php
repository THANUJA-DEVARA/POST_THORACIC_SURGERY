<?php
$username="";
$email="";
$password="";
$confirmPass="";
$flag=0;
$errors = array();
$sentotp="default";
?>